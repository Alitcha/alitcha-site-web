<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
                <div class="alert alert-info" role="alert">
                    
                      <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
<div class="card">

              <div class="card-header border-transparent">
                <h3 class="card-title">Les éditeurs</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <div class="table-responsive">
                  <table class="table m-0">
                    <thead>
                    <tr>
                      <th>Nom</th>
                      <th>Prénom</th>
                      <th>Email</th>
                      <th></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $editors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($editor->lastname); ?></td>
                            <td><?php echo e($editor->firstname); ?></td>
                            <td><?php echo e($editor->email); ?>  <?php if($editor->email === Auth::user()->email): ?> <span class="badge bg-info ml-1">vous</span> <?php endif; ?></td>

                            <td>
                                <?php if(Auth::user()->isAdmin()): ?>
                                <a role="button" class="btn btn-danger btn-sm"
                                onclick="event.preventDefault(); document.getElementById('destroy<?php echo e($editor->id); ?>').submit();">
                                Démettre</a>
                                <?php endif; ?>
                            </td>
                            <?php if(Auth::user()->isAdmin()): ?>
                            <form id="destroy<?php echo e($editor->id); ?>" action="<?php echo e(route('editor.remove',$editor->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <!-- <?php echo method_field('DELETE'); ?>-->
                            </form>
                            <?php endif; ?>

                           
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.table-responsive -->
              </div>
              <!-- /.card-body -->
              
              <div class="card-footer clearfix">
              <?php if(Auth::user()->isAdmin()): ?>
                <a href="<?php echo e(route('editor.add')); ?>" class="btn btn-sm btn-secondary float-left">Nommer un éditeur</a>
                <?php endif; ?>  
            </div>
              
              <!-- /.card-footer -->
            </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://kit.fontawesome.com/1f9f6c8634.js" crossorigin="anonymous"></script>

    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/donatien/Documents/alitchaWebsite/backend/alitchaWebSite/resources/views/editor/index.blade.php ENDPATH**/ ?>