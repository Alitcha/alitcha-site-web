<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="col-md-10 offset-md-1 ">

            <form method="post" action="<?php echo e(route('article.update',$article->id)); ?>">
                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>
                
                <?php if(session()->has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('message')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                          <?php if($errors->has("title")): ?>
                          <li>Titre obligatoire</li>
                          <?php endif; ?>
                          <?php if($errors->has("image")): ?>
                          <li>Image obligatoire</li>
                          <?php endif; ?>
                          <?php if($errors->has("content")): ?>
                          <li>Corps de l'article obligatiore</li>
                          <?php endif; ?>
                            
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="float-right mb-3">
                  <button type="submit" class="btn btn-primary">Enregistrer</button>
                  
                  <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#imgmodal">
                  Images    
                  </button>

                </div>

                
                <div class="from-group mb-2">
                <input id="title" name="title" class="form-control  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Titre" type="input" name="content" value="<?php echo e(old('title',$article->title)); ?>" />
                
                </div>

                <div class="from-group mb-2">
                  <textarea name="subtitle" id="subtitle"  class="form-control  <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Sous titre..."><?php echo e($article->subtitle); ?></textarea>
                 
                </div>

                
                <div class="from-group mb-2">
                <input id="image" name="image" class="form-control  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="L'url de l'image principale (copier/coller)" type="input" name="content" value="<?php echo e(old('image',$article->image)); ?>" />
                  
                </div>

                <div>
                  
                  <select id="categorie" name="categorie" class="form-select mb-2" aria-label="Default select example">
                 
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                    <?php if($cat->id == $article->categorie_id): ?>
                        <option  value="<?php echo e($cat->id); ?>" selected ><?php echo e($cat->name); ?></option>
                    <?php else: ?>
                      <option  value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  
                </div>
                
            
                <div class="from-group mb-2">
                    <textarea id="content" type="hidden" name="content">
                    <?php echo $article->content; ?>

                    </textarea>
                    <!-- <input id="content" type="hidden" name="content" value="<?php echo e(old('content')); ?>" /> -->
                    
                    <!--<trix-editor input="content" class="trix-content"></trix-editor>-->
                </div>
               <!-- <input type="submit" name="submit" value="Enregistrer" class="btn btn-primary"/>-->
            </form>
        </div>

        <!-- Modal -->
<div class="modal fade " id="imgmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-xl modal-fullscreen-sm-down">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Image à insérer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
           <div class="row">
           <?php if($images->count()==0): ?>
                    <span class="alert alert-info">Aucune image ! Ajoutez des images dans la section image pour les retrouver ici.</span>
            <?php else: ?>
                  <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3" id="<?php echo e('img'.$img->id); ?>" >
                        
                        <img src="<?php echo e(asset('images/'.$img->path_name)); ?>" class="img-thumbnail" alt="...">
                        <span class="" id="<?php echo e('text'.$img->id); ?>">http://localhost:8000/images/<?php echo e($img->path_name); ?></span>
                        <i class="fa-solid fa-copy" id="<?php echo e('btn'.$img->id); ?>" data-target="<?php echo e('#text'.$img->id); ?>" onclick ="copy('btn<?php echo e($img->id); ?>');"></i>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
        
      </div>
    </div>
  </div>
</div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/trix.css')); ?>">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://kit.fontawesome.com/1f9f6c8634.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

<script src="https://cdn.tiny.cloud/1/ii55vmuwsr4ox819yjuuyda651l53xnp90lx4dbt3zky9jeu/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>

function copy(id) {
    // Cible de l'élément qui doit être copié
    let elem = document.getElementById(id);
    //alert(elem.value);
    var target = elem.dataset.target;
    var fromElement = document.querySelector(target);
    if(!fromElement) return;

    // Sélection des caractères concernés
    var range = document.createRange();
    var selection = window.getSelection();
    range.selectNode(fromElement);
    selection.removeAllRanges();
    selection.addRange(range);

    try {
        // Exécution de la commande de copie
        var result = document.execCommand('copy');
        if (result) {
            // La copie a réussi
            alert('Copié');
        }
    }
    catch(err) {
        // Une erreur est surevnue lors de la tentative de copie
        alert(err);
    }

    // Fin de l'opération
    selection = window.getSelection();
    if (typeof selection.removeRange === 'function') {
        selection.removeRange(range);
    } else if (typeof selection.removeAllRanges === 'function') {
        selection.removeAllRanges();
    }
  }
  //plugins: 'a11ychecker advcode advlist casechange export formatpainter image editimage  autolink help lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tableofcontents  tinymcespellchecker',
    tinymce.init({
      selector: '#content',
      plugins: 'advlist image autolink help lists fullscreen media table',
      toolbar: 'undo redo  blocks bold italic forecolor backcolor fontsize  font alignleft  aligncenter alignright alignjustify image fullscreen | help bullist numlist outdent indent | format  casechange checklist code   editimage table formatpainter',
      toolbar_mode: 'floating',
      relative_urls : true,
      document_base_url : location.host,
      /* enable title field in the Image dialog*/
  image_title: true,
  height : screen.height*0.75,
  
  /* enable automatic uploads of images represented by blob or data URIs*/
  //automatic_uploads: true,
  /*
    URL of our upload handler (for more details check: https://www.tiny.cloud/docs/configure/file-image-upload/#images_upload_url)
    images_upload_url: 'postAcceptor.php',
    here we add custom filepicker only to Image dialog
  */
  
    });
  </script>
      
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/donatien/Documents/alitchaWebsite/backend/alitchaWebSite/resources/views/article/edit.blade.php ENDPATH**/ ?>