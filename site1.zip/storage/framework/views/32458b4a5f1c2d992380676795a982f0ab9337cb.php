<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'warning','title' => 'Warning'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    Warning theme callout!
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
    <div class="row">
    <div class="col-md-4">
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => '528','text' => 'User Registrations','icon' => 'fas fa-user-plus text-teal','theme' => 'primary','url' => '#','urlText' => 'View all users'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => '424','text' => 'Views','icon' => 'fas fa-eye text-dark','theme' => 'teal','url' => '#','urlText' => 'View details'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => '0','text' => 'Reputation','icon' => 'fas fa-medal text-dark','theme' => 'danger','url' => '#','urlText' => 'Reputation history'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'sbUpdatable']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    
    </div>
    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/donatien/Documents/alitchaWebsite/backend/alitchaWebSite/resources/views/admin/admin-editor.blade.php ENDPATH**/ ?>