<?php $__env->startSection('title', ''); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session()->has('message')): ?>
                <div class="alert alert-info" role="alert">
                    
                      <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
<div class="card">

              <div class="card-header border-transparent">
                <h3 class="card-title">Users</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <div class="table-responsive">
                  <table class="table m-0">
                    <thead>
                    <tr>
                      <th>Nom</th>
                      <th>Prénom</th>
                      <th>Email</th>
                      <th>Rôle</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->lastname); ?></td>
                            <td><?php echo e($user->firstname); ?> </td>
                            <td><?php echo e($user->email); ?> <?php if($user->email === Auth::user()->email): ?> <span class="badge bg-info ml-1">vous</span> <?php endif; ?></td>

                            <td>
                              <?php if($user->isAdmin() or $user->isEditor()): ?>
                               <span class="badge bg-success"> <?php echo e($user->role()); ?> </span>
                                <?php endif; ?>
                            </td>
                            

                           
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.table-responsive -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix">
         
            </div>
              <!-- /.card-footer -->
            </div>
    
<?php $__env->stopSection(); ?>



<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://kit.fontawesome.com/1f9f6c8634.js" crossorigin="anonymous"></script>

    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/donatien/Documents/alitchaWebsite/backend/alitchaWebSite/resources/views/admin/user.blade.php ENDPATH**/ ?>