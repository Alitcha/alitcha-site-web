<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(!Auth::user()->isAdmin() && !Auth::user()->isEditor()): ?>
    <?php if (isset($component)) { $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class, ['theme' => 'info','title' => 'Info'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-callout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\Callout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        Vous n'avez aucun rôle pour le moment. Demandez à être nommé éditeur ou admin ou connectez vous à un autre compte. <br>
        Merci
        
        <a class=""  href="/admin/request">
            <button  class="btn  btn-primary d-block mt-1 btn-sm"  >
                Faire la demande
            </button>
        </a>
        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62)): ?>
<?php $component = $__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62; ?>
<?php unset($__componentOriginald4eaa7d50c9a38ea504d56c2c2f22775c77b7f62); ?>
<?php endif; ?>
    <?php else: ?>

    <div class="row">
    <div class="col-md-4">
        <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => ''.e($nbusers).'','text' => 'Inscriptions','icon' => 'fas fa-user-plus text-teal','theme' => 'primary','url' => ''.e(route('users.list')).'','urlText' => 'Voirs tous les utilisateurs'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => ''.e($nbpub).'','text' => 'Articles publiés','icon' => 'fas fa-file text-white','theme' => 'teal','url' => ''.e(route('article.index')).'','urlText' => ''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    <div class="col-md-4">
    <?php if (isset($component)) { $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086 = $component; } ?>
<?php $component = $__env->getContainer()->make(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class, ['title' => ''.e($nbunpub).'','text' => 'Articles en cours d\'édition','icon' => 'fas fa-file text-dark','theme' => 'danger','url' => ''.e(route('article.index')).'','urlText' => ''] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-small-box'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Widget\SmallBox::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086)): ?>
<?php $component = $__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086; ?>
<?php unset($__componentOriginala47f63f833c8b0a47e1f17ee6833237811ae9086); ?>
<?php endif; ?>
    </div>
    
    </div>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>

   /* $(document).ready(function() {

        let sBox = new _AdminLTE_SmallBox('sbUpdatable');

        let updateBox = () =>
        {
            // Stop loading animation.
            sBox.toggleLoading();

            // Update data.
            let rep = Math.floor(1000 * Math.random());
            let idx = rep < 100 ? 0 : (rep > 500 ? 2 : 1);
            let text = 'Reputation - ' + ['Basic', 'Silver', 'Gold'][idx];
            let icon = 'fas fa-medal ' + ['text-primary', 'text-light', 'text-warning'][idx];
            let url = ['url1', 'url2', 'url3'][idx];

            let data = {text, title: rep, icon, url};
            sBox.update(data);
        };

        let startUpdateProcedure = () =>
        {
            // Simulate loading procedure.
            sBox.toggleLoading();

            // Wait and update the data.
            setTimeout(updateBox, 2000);
        };

        setInterval(startUpdateProcedure, 10000);
    })*/

</script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://kit.fontawesome.com/1f9f6c8634.js" crossorigin="anonymous"></script>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/donatien/Documents/alitchaWebsite/backend/alitchaWebSite/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>